<template>
    <indexnav></indexnav>
</template>
<script setup lang="ts">
    import register from './pages/register.vue';
    import indexnav from './components/project/nav.vue';
    import login from './pages/login.vue';
</script>


